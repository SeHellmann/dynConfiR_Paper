library(testthat)
library(dynConfiR)

test_check("dynConfiR")
